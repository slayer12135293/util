export default function() {
    return [
        {
            id: 1,
            first: "Homer",
            last: "Simpson",
            age: 36,
            description: "Homer rocks",
            thumbnail: "https://upload.wikimedia.org/wikipedia/en/0/02/Homer_Simpson_2006.png",
            location: {lat: 59.3378580, lng: 18.0125720}
        },
        {
            id: 2,
            first: "Barney",
            last: "Gumble",
            age: 10,
            description: "Barney rocks",
            thumbnail: "https://englishvg1.wikispaces.com/file/view/image012.gif/33664991/215x219/image012.gif",
            location: {lat: 57.3378580, lng: 17.0125720}
        },
        {
            id: 3,
            first: "Marge",
            last: "Simpson",
            age: 36,
            description: "Marge rocks",
            thumbnail: "http://i.imgur.com/nrBMnaB.png",
            location: {lat: 56.3378580, lng: 18.0125720}
        }
    ]
}