import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import GoogleMapReact from 'google-map-react';


class UserDetail extends Component {
    constructor(props){
        super(props)
        this.state={
            centerLat : 40,
            centerLng : 40
        }
    }
    render() {
        const { user } = this.props;
        const { centerLat, centerLng } = this.state        

        const LocationPoint = ({ text }) => <div className="location-point">{text}</div>;
        return (
            <div className="user-region">

                <div className="user-detail">
                    <img src={user.thumbnail} />
                    <h2> {user.first}  {user.last}</h2>
                </div>

                <div className="map">
                    <GoogleMapReact
                        bootstrapURLKeys={{ key: 'AIzaSyC6SAcwZ895KK7ckh4fmZVPSS2OE4xe0nk' }}
                        //bootstrapURLKeys={{ key: 'AIzaSyC4R6AN7SmujjPUIGKdyao2Kqitzr1kiRg' }}
                        defaultCenter={ user === '' ? {lat: 59.3378580, lng: 18.0125720} : user.location }
                        defaultZoom={11}
                    >
                        <LocationPoint
                            lat={user === '' ? centerLat: user.location.lat}
                            lng={user === '' ? centerLng: user.location.lng}
                            text={user.first + ' ' +user.last}
                        />
                    </GoogleMapReact>
                </div>
            </div>

        )
    }
}

function mapStatetoProps(state) {
    return {
        user: state.activeUser
    };
}

export default connect(mapStatetoProps)(UserDetail)