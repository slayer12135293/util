import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

class Map extends Component {
    constructor(){
        super()
        map = new Microsoft.Maps.Map('#myMap', {});
    }

    render(){
        return (
            <div id ='myMap'>
            map
            </div>
        )
    }
}

export default Map